﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class PlayerWindowManager : MonoBehaviour{

	void Start () {

	}
	
	void Update () {
	
	}
}
