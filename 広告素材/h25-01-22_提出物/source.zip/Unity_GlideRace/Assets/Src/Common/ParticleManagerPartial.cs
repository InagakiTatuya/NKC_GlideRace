﻿
//#################################################################################################
//  作・稲垣達也
//  パーティクルを管理するIndex番号を定義する
//#################################################################################################

using UnityEngine;

public partial class ParticleManager : MonoBehaviour {
    public const int PAR_DRIFT     = 0;
    public const int PAR_TEST_1    = 1;
    public const int PAR_TEST_2    = 2;
}
