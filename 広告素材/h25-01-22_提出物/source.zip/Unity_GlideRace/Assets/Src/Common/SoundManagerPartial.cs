﻿//#################################################################################################
//  作・稲垣達也
//  サウンドを管理するIndex番号を定義する
//#################################################################################################

using UnityEngine;
using System.Collections;

public partial class SoundManager {
    public const int SE_TEST_0	=  0;
    public const int SE_TEST_1	=  1;
    public const int SE_TEST_2	=  2;
    public const int SE_TEST_3	=  3;
    public const int SE_TEST_4	=  4;
    public const int SE_TEST_5	=  5;
    public const int SE_TEST_6	=  6;
    public const int SE_TEST_7	=  7;
    public const int SE_TEST_8	=  8;
    public const int SE_TEST_9	=  9;

}
